# Green Moon Store V3 — Direct Image Upload via D1 BLOB

رفع الصورة من الموبايل مباشرة إلى Worker عبر multipart، ثم تخزينها كـBLOB منفصل في D1. لا KV ولا R2 ولا Cloudinary ولا GitHub Token.
