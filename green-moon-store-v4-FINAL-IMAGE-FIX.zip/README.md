# Green Moon Store — Clean Rebuild v4

One Cloudflare Worker + D1 + static assets. No KV, R2, Cloudinary or GitHub token is required for product images.

## Deploy
1. Keep the existing Cloudflare Worker `green-moon-store` and D1 binding.
2. Deploy this project from GitHub Workers Builds.
3. `ADMIN_SECRET` remains a Cloudflare Secret.
4. Public: `/` — Admin: `/admin`.

## Images
The admin uploads JPG/PNG/WEBP/GIF directly to `/api/admin/products/:id/image`; the Worker stores the binary in D1 table `product_image_blobs` and serves it at `/api/product-image/:id`.


## 2026-09-19 change
The category/sections feature was removed from the public storefront and admin UI. Products no longer accept or write category_id; the legacy categories table is intentionally retained unused for migration safety.


Image hardening: public product responses now always use stable `/api/product-image/:id` URLs. The image endpoint reads the D1 BLOB first and falls back to legacy KV `/media/` objects for older products. Mobile product grids center a lone product card.
