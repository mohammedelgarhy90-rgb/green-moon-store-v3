# Green Moon Store — V6 D1-only rebuild

Production architecture: one Cloudflare Worker + D1 + static assets. No KV namespace is used or required.

- Product images uploaded from Admin are stored as binary BLOBs in the D1 `product_image_blobs` table.
- Public image delivery uses `/api/product-image/{id}` and preserves the uploaded MIME type.
- Public APIs never expose wholesale/cost prices.
- Admin uses `ADMIN_SECRET`.
- Existing static Green Moon bamboo/pothos images remain available as legacy fallbacks.

## Important
Images that existed only in the old KV namespace are not migrated by this package. Re-upload those images from Admin so they are stored in D1. The KV binding has been removed from `wrangler.toml`.
