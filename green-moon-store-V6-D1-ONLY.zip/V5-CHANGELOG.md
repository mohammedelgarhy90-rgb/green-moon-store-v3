# V5 audit / rebuild

Detected and corrected issues from the previous build:

1. Product image upload was coupled to D1 BLOB delivery. V5 stores the uploaded binary in KV with a stable key `products/{productId}/image` and uses `/api/product-image/{id}` for delivery. D1 BLOB remains a fallback for existing records.
2. Product creation no longer accepts a free-text category ID in the admin UI; categories are loaded from D1 and the backend validates the selected category.
3. Public APIs strip wholesale and cost prices.
4. Checkout recalculates product prices from D1 instead of trusting browser prices.
5. Admin image upload verifies the product exists, validates MIME and size, stores the image, and updates the DB URL in one flow.
6. Product deletion also deletes its KV image.
7. Admin login uses `ADMIN_SECRET` and an HMAC session token.
8. No Worker-to-Worker proxying or geolocation/GPS code.
9. Frontend cache busting is handled by `app.js?v=5`.
10. Existing D1 data is preserved; no destructive migration is included.
