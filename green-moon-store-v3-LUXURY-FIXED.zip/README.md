# Green Moon Store — Luxury Fixed Build

نسخة Green Moon Mobile Luxury مع:
- واجهة RTL فاخرة أخضر داكن + ذهبي + عاجي.
- نسخة موبايل محسنة.
- المنتجات والتصنيفات والصفقات والسلة والطلبات.
- لوحة التحكم الحالية.
- Green Moon Doctor.
- ضغط صورة Doctor قبل إرسالها إلى Workers AI لتقليل مشاكل حجم/توكنات الصورة.
- Worker متوافق مع Cloudflare Workers + KV + Workers AI.

## Cloudflare
Wrangler entrypoint:
`worker.js`

Assets:
`public`

Worker secret المطلوب:
`ADMIN_PASSWORD`

لا تضع كلمة مرور الإدارة داخل `wrangler.toml`.
