# Green Moon Store V3

Image storage mode: direct image URL. The admin product form accepts a public direct image URL and saves it in D1. No KV/R2 upload is required for product images.
