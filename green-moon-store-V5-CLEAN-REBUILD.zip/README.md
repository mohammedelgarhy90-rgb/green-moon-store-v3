# Green Moon Store V5 — Clean Rebuild

Production architecture: one Cloudflare Worker + D1 + KV + static assets.

## Important
- Uses the existing `green-moon-db` and `green-moon-images` bindings; it does not delete or reset existing data.
- Product images uploaded from Admin are stored in KV under a stable product key and referenced by `/media/products/{id}.webp`.
- Public image delivery first reads KV, then falls back to the existing D1 BLOB storage, then the known Green Moon static photos for legacy bamboo/pothos records.
- Admin product categories are selected from the database; the backend validates category IDs.
- Wholesale and cost prices are never returned by public product APIs.
- Admin routes require the `ADMIN_SECRET` secret.
- No geolocation, GPS, Worker-to-Worker proxying, or client-side price trust.

## Deploy
`npx wrangler deploy`
