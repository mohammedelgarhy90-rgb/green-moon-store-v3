const CORS={"access-control-allow-origin":"*","access-control-allow-methods":"GET,POST,PUT,DELETE,OPTIONS","access-control-allow-headers":"Content-Type,Authorization"};
const JSON_HEADERS={"content-type":"application/json; charset=utf-8","cache-control":"no-store"};
const S=v=>v==null?"":String(v);
const N=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const I=(v,d=0)=>Number.isFinite(parseInt(v,10))?parseInt(v,10):d;
const B=v=>v===true||v===1||v==="1"||v==="true"||v==="on";
const esc=v=>S(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
function json(data,status=200,extra={}){return new Response(JSON.stringify(data),{status,headers:{...JSON_HEADERS,...extra}})}
function ok(data={},status=200,extra={}){return json({success:true,...data},status,extra)}
function bad(code,message,status=400,detail=""){return json({success:false,error:{code,message,detail: S(detail)}} ,status)}
async function bodyJson(r){try{return await r.json()}catch{return {}}}
function slug(v){return S(v).trim().toLowerCase().replace(/[^\p{L}\p{N}]+/gu,"-").replace(/^-+|-+$/g,"")||`product-${Date.now()}`}
function safeProduct(p){if(!p)return p;const {wholesale_price,cost_price,...rest}=p;return rest}
function cookie(r,name){const x=r.headers.get("cookie")||"";const m=x.match(new RegExp(`(?:^|; )${name}=([^;]*)`));return m?decodeURIComponent(m[1]):""}
function b64(bytes){let s="";for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"")}
function ub64(s){s=s.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";const x=atob(s),a=new Uint8Array(x.length);for(let i=0;i<x.length;i++)a[i]=x.charCodeAt(i);return a}
async function mac(secret,text){return new Uint8Array(await crypto.subtle.sign("HMAC",await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]),new TextEncoder().encode(text)))}
async function makeSession(secret){const exp=Math.floor(Date.now()/1000)+86400;const p=`admin.${exp}`;return `${p}.${b64(await mac(secret,p))}`}
async function isAdmin(r,e){const t=(r.headers.get("authorization")||"").replace(/^Bearer\s+/i,"").trim()||cookie(r,"gm_admin");const a=t.split(".");if(a.length!==3||a[0]!=="admin"||!e.ADMIN_SECRET)return false;if(Number(a[1])<Math.floor(Date.now()/1000))return false;try{const sig=await mac(e.ADMIN_SECRET,`${a[0]}.${a[1]}`),got=ub64(a[2]);if(sig.length!==got.length)return false;let z=0;for(let i=0;i<sig.length;i++)z|=sig[i]^got[i];return z===0}catch{return false}}
function authCookie(token){return `gm_admin=${encodeURIComponent(token)}; Path=/; Max-Age=86400; HttpOnly; Secure; SameSite=Lax`}
function imageType(path){const ext=S(path).split(".").pop().toLowerCase();return ({jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",webp:"image/webp",gif:"image/gif"}[ext]||"application/octet-stream")}
const KEY=id=>`products/${id}/image`;
function legacyFallback(p){const label=(S(p?.name)+" "+S(p?.slug)).toLowerCase();if(label.includes("بامبو")||label.includes("bamboo"))return "/assets/products/bamboo-real-2026-09-20.jpg";if(label.includes("بوتس")||label.includes("pothos"))return "/assets/products/pothos-real-2026-09-20.jpg";return "/assets/placeholder.svg"}
async function productImage(r,e,id){
  const p=await e.DB.prepare("SELECT id,name,slug,image_url FROM products WHERE id=? LIMIT 1").bind(id).first();
  if(!p)return new Response("Not found",{status:404});
  if(e.IMAGES){const v=await e.IMAGES.get(KEY(id),"arrayBuffer");if(v){const h={"content-type":"image/webp","cache-control":"no-store","x-content-type-options":"nosniff"};return r.method==="HEAD"?new Response(null,{headers:h}):new Response(v,{headers:h})}}
  try{const b=await e.DB.prepare("SELECT mime,data FROM product_image_blobs WHERE product_id=? LIMIT 1").bind(id).first();if(b?.data){const h={"content-type":S(b.mime)||"image/webp","cache-control":"no-store","x-content-type-options":"nosniff"};return r.method==="HEAD"?new Response(null,{headers:h}):new Response(b.data,{headers:h})}}catch{}
  const fallback=legacyFallback(p);if(fallback!=="/assets/placeholder.svg")return Response.redirect(new URL(fallback,r.url),302);
  return new Response("Image not found",{status:404,headers:{"cache-control":"no-store"}})
}
function publicImageUrl(p){if(!p)return "/assets/placeholder.svg";const raw=S(p.image_url);if(raw.startsWith("/media/products/"))return `/api/product-image/${p.id}`;if(raw.startsWith("/api/product-image/"))return raw;if(raw.startsWith("http://")||raw.startsWith("https://"))return raw;return legacyFallback(p)}
async function saveImage(r,e,id){
  const p=await e.DB.prepare("SELECT id FROM products WHERE id=? LIMIT 1").bind(id).first();if(!p)return bad("PRODUCT_NOT_FOUND","المنتج غير موجود",404);
  const ct=r.headers.get("content-type")||"";if(!ct.toLowerCase().includes("multipart/form-data"))return bad("INVALID_UPLOAD","ملف الصورة مطلوب",422);
  const fd=await r.formData();const file=fd.get("file");if(!file||typeof file.arrayBuffer!=="function")return bad("INVALID_UPLOAD","ملف الصورة مطلوب",422);
  const type=S(file.type).toLowerCase();if(!["image/jpeg","image/png","image/webp","image/gif"].includes(type))return bad("INVALID_UPLOAD","الصورة لازم تكون JPG أو PNG أو WebP أو GIF",422);
  const size=N(file.size);if(size<=0||size>1800000)return bad("FILE_TOO_LARGE","الصورة لازم تكون أقل من 1.8 ميجابايت بعد الضغط",413);
  const data=await file.arrayBuffer();if(e.IMAGES)await e.IMAGES.put(KEY(id),data,{httpMetadata:{contentType:type,cacheControl:"no-store"}});
  await e.DB.prepare("UPDATE products SET image_url=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(`/media/products/${id}.webp`,id).run();
  return ok({image_url:`/api/product-image/${id}`,bytes:size,stored:"kv"});
}
async function storeApi(r,e,u){
  const p=u.pathname,m=r.method;
  if(p==="/api/health"&&m==="GET")return ok({service:"green-moon-store",version:"5.0.0",status:"ok"});
  if(p==="/api/store"&&m==="GET"){
    const [c,ps,o,f,a,rv,se,cm,mi]=await Promise.all([
      e.DB.prepare("SELECT id,name,slug,image_url,description,sort_order,active FROM categories WHERE active=1 ORDER BY sort_order,id").all(),
      e.DB.prepare("SELECT * FROM products WHERE is_available=1 ORDER BY is_featured DESC,sort_order,id DESC").all(),
      e.DB.prepare("SELECT * FROM offers WHERE active=1 ORDER BY id DESC").all(),
      e.DB.prepare("SELECT * FROM flash_sales WHERE active=1 ORDER BY id DESC").all(),
      e.DB.prepare("SELECT * FROM articles WHERE published=1 ORDER BY published_at DESC,id DESC LIMIT 12").all(),
      e.DB.prepare("SELECT * FROM reviews WHERE active=1 ORDER BY id DESC LIMIT 12").all(),
      e.DB.prepare("SELECT key,value FROM settings").all(),e.DB.prepare("SELECT key,value FROM cms_content").all(),e.DB.prepare("SELECT * FROM menu_items WHERE active=1 ORDER BY sort_order,id").all()
    ]);
    return ok({categories:c.results||[],products:(ps.results||[]).map(p=>({...safeProduct(p),image_url:publicImageUrl(p)})),offers:o.results||[],flashSales:f.results||[],articles:a.results||[],reviews:rv.results||[],settings:Object.fromEntries((se.results||[]).map(x=>[x.key,x.value])),cms:Object.fromEntries((cm.results||[]).map(x=>[x.key,x.value])),menu:mi.results||[]});
  }
  if(p==="/api/products"&&m==="GET"){
    const q=S(u.searchParams.get("q")),cat=I(u.searchParams.get("category"));let sql="SELECT * FROM products WHERE is_available=1",args=[];
    if(q){sql+=" AND (name LIKE ? OR description LIKE ?)";args.push(`%${q}%`,`%${q}%`)}if(cat){sql+=" AND category_id=?";args.push(cat)}sql+=" ORDER BY is_featured DESC,sort_order,id DESC LIMIT 100";
    const x=await e.DB.prepare(sql).bind(...args).all();return ok({products:(x.results||[]).map(p=>({...safeProduct(p),image_url:publicImageUrl(p)}))});
  }
  const pm=p.match(/^\/api\/products\/(\d+)$/);if(pm&&m==="GET"){
    const id=I(pm[1]),x=await e.DB.prepare("SELECT * FROM products WHERE id=? AND is_available=1").bind(id).first();if(!x)return bad("PRODUCT_NOT_FOUND","المنتج غير موجود",404);
    const [imgs,sim]=await Promise.all([e.DB.prepare("SELECT id,product_id,image_url,sort_order FROM product_images WHERE product_id=? ORDER BY sort_order,id").bind(id).all(),x.category_id?e.DB.prepare("SELECT * FROM products WHERE category_id=? AND id<>? AND is_available=1 ORDER BY is_featured DESC,sort_order,id DESC LIMIT 8").bind(x.category_id,id).all():Promise.resolve({results:[]})]);
    return ok({product:{...safeProduct(x),image_url:publicImageUrl(x),images:(imgs.results||[]).map(i=>({...i,image_url:publicImageUrl({...x,image_url:i.image_url})}))},similar:(sim.results||[]).map(p=>({...safeProduct(p),image_url:publicImageUrl(p)}))});
  }
  if(p==="/api/orders"&&m==="POST"){
    const b=await bodyJson(r);if(!S(b.name)||!S(b.phone)||!Array.isArray(b.items)||!b.items.length)return bad("INVALID_ORDER","الاسم والهاتف والمنتجات مطلوبة",422);
    const ids=[...new Set(b.items.map(i=>I(i.productId)).filter(Boolean))];const rows=await e.DB.prepare(`SELECT id,name,price,stock,is_available FROM products WHERE id IN (${ids.map(()=>"?").join(",")})`).bind(...ids).all();const map=new Map((rows.results||[]).map(x=>[x.id,x]));let sub=0;const items=[];
    for(const i of b.items){const q=Math.max(1,I(i.quantity,1)),x=map.get(I(i.productId));if(!x||!x.is_available)return bad("PRODUCT_UNAVAILABLE","منتج غير متاح",409);if(I(x.stock)<q)return bad("OUT_OF_STOCK",`الكمية المتاحة من ${x.name} غير كافية`,409);const total=N(x.price)*q;sub+=total;items.push({productId:x.id,productName:x.name,quantity:q,unitPrice:N(x.price),total})}
    const delivery=Math.max(0,N(b.deliveryFee)),total=sub+delivery;const cr=await e.DB.prepare("SELECT id FROM customers WHERE phone=? ORDER BY id DESC LIMIT 1").bind(S(b.phone)).first();let customerId=cr?.id||null;
    if(customerId)await e.DB.prepare("UPDATE customers SET name=?,whatsapp=?,governorate=?,area=?,building=?,floor=?,apartment=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(S(b.name),S(b.whatsapp),S(b.governorate),S(b.area),S(b.building),S(b.floor),S(b.apartment),customerId).run();else{const c=await e.DB.prepare("INSERT INTO customers(name,phone,whatsapp,governorate,area,building,floor,apartment) VALUES(?,?,?,?,?,?,?,?)").bind(S(b.name),S(b.phone),S(b.whatsapp),S(b.governorate),S(b.area),S(b.building),S(b.floor),S(b.apartment)).run();customerId=c.meta.last_row_id}
    const o=await e.DB.prepare("INSERT INTO orders(customer_id,name,phone,whatsapp,governorate,area,building,floor,apartment,notes,subtotal,delivery_fee,total,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(customerId,S(b.name),S(b.phone),S(b.whatsapp),S(b.governorate),S(b.area),S(b.building),S(b.floor),S(b.apartment),S(b.notes),sub,delivery,total,"new").run();const oid=o.meta.last_row_id;
    for(const i of items){await e.DB.prepare("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price,total) VALUES(?,?,?,?,?,?)").bind(oid,i.productId,i.productName,i.quantity,i.unitPrice,i.total).run();await e.DB.prepare("UPDATE products SET stock=MAX(0,stock-?),updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(i.quantity,i.productId).run()}
    const msg=`طلب جديد #${oid}%0Aالاسم: ${encodeURIComponent(S(b.name))}%0Aالهاتف: ${encodeURIComponent(S(b.phone))}%0Aالإجمالي: ${total} جنيه`;
    return ok({order:{id:oid,total,subtotal:sub,delivery_fee:delivery,items},whatsapp:`https://wa.me/${e.WHATSAPP}?text=${msg}`});
  }
  if(p.startsWith("/api/admin/")&&!await isAdmin(r,e))return bad("UNAUTHORIZED","سجل الدخول أولًا",401);
  return adminApi(r,e,u);
}
async function adminApi(r,e,u){
  const p=u.pathname,m=r.method;
  if(p==="/api/admin/login"&&m==="POST")return bad("NOT_FOUND","المسار غير موجود",404); // handled before auth in fetch
  if(p==="/api/admin/logout"&&m==="POST")return ok({},200,{"set-cookie":"gm_admin=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax"});
  if(p==="/api/admin/me"&&m==="GET")return ok({user:{role:"admin"}});
  if(p==="/api/admin/dashboard"&&m==="GET"){
    const [products,orders,customers,categories]=await Promise.all([e.DB.prepare("SELECT COUNT(*) n FROM products").first(),e.DB.prepare("SELECT COUNT(*) n FROM orders").first(),e.DB.prepare("SELECT COUNT(*) n FROM customers").first(),e.DB.prepare("SELECT COUNT(*) n FROM categories").first()]);
    return ok({stats:{products:N(products?.n),orders:N(orders?.n),customers:N(customers?.n),categories:N(categories?.n)}});
  }
  if(p==="/api/admin/products"&&m==="GET"){const x=await e.DB.prepare("SELECT * FROM products ORDER BY sort_order,id DESC").all();return ok({products:x.results||[]})}
  if(p==="/api/admin/categories"&&m==="GET"){const x=await e.DB.prepare("SELECT id,name,slug,active FROM categories ORDER BY sort_order,id").all();return ok({categories:x.results||[]})}
  if(p==="/api/admin/products"&&m==="POST"){
    const b=await bodyJson(r);if(!S(b.name).trim())return bad("INVALID_PRODUCT","اسم المنتج مطلوب",422);let sl=slug(b.slug||b.name),base=sl,n=1;while(await e.DB.prepare("SELECT id FROM products WHERE slug=?").bind(sl).first()){sl=`${base}-${++n}`}
    const cat=I(b.categoryId||b.category_id);if(cat&&!await e.DB.prepare("SELECT id FROM categories WHERE id=? AND active=1").bind(cat).first())return bad("INVALID_CATEGORY","القسم المختار غير موجود",422);
    try{const x=await e.DB.prepare("INSERT INTO products(name,slug,description,image_url,category_id,price,old_price,wholesale_price,cost_price,stock,is_available,is_featured,sort_order,badge,discount_percent) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(S(b.name),sl,S(b.description),"",cat||null,N(b.price),N(b.oldPrice??b.old_price),N(b.wholesalePrice??b.wholesale_price),N(b.costPrice??b.cost_price),I(b.stock),B(b.isAvailable??b.is_available)?1:0,B(b.isFeatured??b.is_featured)?1:0,I(b.sortOrder??b.sort_order),S(b.badge),N(b.discountPercent??b.discount_percent)).run();return ok({id:x.meta.last_row_id,slug:sl})}catch(err){return bad("PRODUCT_SAVE_FAILED","تعذر حفظ المنتج",500,err.message)}
  }
  const pm=p.match(/^\/api\/admin\/products\/(\d+)$/);if(pm&&(m==="PUT"||m==="DELETE")){
    const id=I(pm[1]);if(m==="DELETE"){await e.DB.prepare("DELETE FROM products WHERE id=?").bind(id).run();if(e.IMAGES)await e.IMAGES.delete(KEY(id));return ok()}
    const b=await bodyJson(r);if(!S(b.name).trim())return bad("INVALID_PRODUCT","اسم المنتج مطلوب",422);const cat=I(b.categoryId||b.category_id);if(cat&&!await e.DB.prepare("SELECT id FROM categories WHERE id=? AND active=1").bind(cat).first())return bad("INVALID_CATEGORY","القسم المختار غير موجود",422);
    let sl=slug(b.slug||b.name),base=sl,n=1;while(await e.DB.prepare("SELECT id FROM products WHERE slug=? AND id<>?").bind(sl,id).first()){sl=`${base}-${++n}`}
    await e.DB.prepare("UPDATE products SET name=?,slug=?,description=?,category_id=?,price=?,old_price=?,wholesale_price=?,cost_price=?,stock=?,is_available=?,is_featured=?,sort_order=?,badge=?,discount_percent=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(S(b.name),sl,S(b.description),cat||null,N(b.price),N(b.oldPrice??b.old_price),N(b.wholesalePrice??b.wholesale_price),N(b.costPrice??b.cost_price),I(b.stock),B(b.isAvailable??b.is_available)?1:0,B(b.isFeatured??b.is_featured)?1:0,I(b.sortOrder??b.sort_order),S(b.badge),N(b.discountPercent??b.discount_percent),id).run();return ok({id,slug:sl});
  }
  const im=p.match(/^\/api\/admin\/products\/(\d+)\/image$/);if(im&&m==="POST")return saveImage(r,e,I(im[1]));
  const gm=p.match(/^\/api\/admin\/(categories|offers|flash_sales|articles|reviews|menu)(?:\/(\d+))?$/);if(gm){
    const key=gm[1],id=I(gm[2]),table=key;const fields={categories:["name","slug","image_url","description","sort_order","active"],offers:["title","description","image_url","price","old_price","start_at","end_at","active"],flash_sales:["title","description","image_url","start_at","end_at","active"],articles:["title","slug","content","image_url","category","published","published_at"],reviews:["product_id","name","rating","content","active"],menu:["label","target","sort_order","active"]}[key];
    if(m==="GET"){const x=await e.DB.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all();return ok({[key]:x.results||[]})}
    if(m==="DELETE"&&id){await e.DB.prepare(`DELETE FROM ${table} WHERE id=?`).bind(id).run();return ok()}
    const b=await bodyJson(r)||{};const cols=fields.filter(f=>Object.prototype.hasOwnProperty.call(b,f));if(!cols.length)return bad("INVALID_DATA","لا توجد بيانات للحفظ",422);
    if(m==="POST"){const x=await e.DB.prepare(`INSERT INTO ${table} (${cols.join(",")}) VALUES (${cols.map(()=>"?").join(",")})`).bind(...cols.map(f=>b[f])).run();return ok({id:x.meta.last_row_id})}
    if(m==="PUT"&&id){await e.DB.prepare(`UPDATE ${table} SET ${cols.map(f=>`${f}=?`).join(",")} WHERE id=?`).bind(...cols.map(f=>b[f]),id).run();return ok({id})}
  }
  if(p==="/api/admin/orders"&&m==="GET"){const x=await e.DB.prepare("SELECT * FROM orders ORDER BY id DESC").all();return ok({orders:x.results||[]})}
  const om=p.match(/^\/api\/admin\/orders\/(\d+)$/);if(om&&m==="PUT"){const b=await bodyJson(r);const allowed=["new","confirmed","delivering","done","cancelled"];if(!allowed.includes(S(b.status)))return bad("INVALID_STATUS","حالة الطلب غير صحيحة",422);await e.DB.prepare("UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(S(b.status),I(om[1])).run();return ok()}
  if(p==="/api/admin/settings"&&m==="GET"){const x=await e.DB.prepare("SELECT key,value FROM settings").all();return ok({settings:Object.fromEntries((x.results||[]).map(x=>[x.key,x.value]))})}
  if(p==="/api/admin/settings"&&m==="PUT"){const b=await bodyJson(r)||{};for(const [k,v] of Object.entries(b))await e.DB.prepare("INSERT INTO settings(key,value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP").bind(S(k),S(v)).run();return ok()}
  if(p==="/api/admin/cms"&&m==="GET"){const x=await e.DB.prepare("SELECT key,value FROM cms_content").all();return ok({cms:Object.fromEntries((x.results||[]).map(x=>[x.key,x.value]))})}
  if(p==="/api/admin/cms"&&m==="PUT"){const b=await bodyJson(r)||{};for(const [k,v] of Object.entries(b))await e.DB.prepare("INSERT INTO cms_content(key,value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP").bind(S(k),S(v)).run();return ok()}
  return bad("NOT_FOUND","المسار غير موجود",404);
}
const LOGIN=`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Green Moon Admin</title><style>body{margin:0;background:#f4f1e7;font-family:Arial;color:#143b2d;display:grid;place-items:center;min-height:100vh}.box{width:min(420px,90vw);background:white;padding:28px;border-radius:22px;box-shadow:0 15px 45px #123b2d20}.box img{width:100px;display:block;margin:0 auto 20px}.box input{width:100%;padding:14px;border:1px solid #ddd;border-radius:12px;box-sizing:border-box;margin:10px 0}.box button{width:100%;padding:14px;border:0;border-radius:12px;background:#064b37;color:white;font-size:16px}.err{color:#b22;margin-top:10px;text-align:center}</style><div class="box"><img src="/assets/green-moon-logo.png"><h2>لوحة تحكم جرين مون</h2><form id="f"><input id="p" type="password" placeholder="كلمة مرور الإدارة" required><button>دخول</button><div class="err" id="e"></div></form></div><script>f.onsubmit=async e=>{e.preventDefault();const r=await fetch('/api/admin/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({password:p.value})});const j=await r.json();if(r.ok){localStorage.setItem('gm_admin_token',j.token);location.href='/admin'}else e.textContent=j.error?.message||'بيانات الدخول غير صحيحة'}</script>`;
export default {async fetch(r,e){const u=new URL(r.url);if(r.method==="OPTIONS")return new Response(null,{status:204,headers:CORS});if(u.pathname==="/api/admin/login"&&r.method==="POST"){const b=await bodyJson(r);if(!e.ADMIN_SECRET||S(b.password)!==S(e.ADMIN_SECRET))return bad("INVALID_LOGIN","بيانات الدخول غير صحيحة",401);const t=await makeSession(e.ADMIN_SECRET);return ok({token:t},200,{"set-cookie":authCookie(t)})}if(u.pathname==="/api/product-image/".replace(/\/$/,""))return bad("NOT_FOUND","الصورة غير موجودة",404);const im=u.pathname.match(/^\/api\/product-image\/(\d+)$/);if(im)return productImage(r,e,I(im[1]));if(u.pathname.startsWith("/api/"))return storeApi(r,e,u);if(u.pathname==="/admin"||u.pathname==="/admin/"){return e.ASSETS.fetch(new Request(new URL("/admin.html",r.url),r))}return e.ASSETS.fetch(r)}};
