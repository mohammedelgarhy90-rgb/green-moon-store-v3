# Green Moon Store V7

Clean rebuild: Cloudflare Worker + D1 + Assets. No KV. Product images are stored as validated binary blobs in D1 with MIME metadata and versioned image URLs.

## Required Secret
`ADMIN_SECRET` — set this in Cloudflare Workers Secrets.

## Deploy
`npx wrangler deploy`

## Important
Do not add a KV binding. The project intentionally has no KV dependency.
