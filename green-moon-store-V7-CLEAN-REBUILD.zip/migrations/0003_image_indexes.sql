CREATE INDEX IF NOT EXISTS idx_products_category_available ON products(category_id,is_available);
CREATE INDEX IF NOT EXISTS idx_products_featured_sort ON products(is_featured,sort_order);
CREATE INDEX IF NOT EXISTS idx_orders_status_created ON orders(status,created_at);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);