# Green Moon — Static Real Image Fix

This build uses unique, cache-busting static filenames for the real product photos:
- /assets/products/bamboo-real-2026-09-20.jpg
- /assets/products/pothos-real-2026-09-20.jpg

The API maps Bamboo/Pothos products directly to these files, bypassing KV/D1 image delivery for these two products.
